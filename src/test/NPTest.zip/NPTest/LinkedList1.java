package test.NPTest;

public class LinkedList1 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		Node_1 cur = new Node_1();
		for (int k = 0; k < 5; ++k) { 
			System.out.println(cur.val);
			cur.nxt = new Node_1();
			cur = cur.nxt;
			cur.nxt = null;
		}
		for (int k = 0; k < 5; ++k) { 
			System.out.println(cur.val);
			cur = cur.nxt;
		}
		System.out.println(cur.val);
		cur = cur.nxt;
	}
}

class Node_1
{
	int val;
	Node_1 nxt;
}