package test.NPTest;

import java.util.Random;

public class Intra_Ptr7 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		A_Ptr7 a = new A_Ptr7();
		A_Ptr7 b = new A_Ptr7();
		b.p = new B_Ptr7();
		b.p.f = new Intra_Ptr7();
		B_Ptr7 c = b.p;
		if ((new Random()).nextBoolean()) {
			b.p.f.x++; //safe
			c.f = null;
			System.out.println(b.p.f.x); //bug
		}
	}
	
	int x;
}

class A_Ptr7 {
	B_Ptr7 p;
}

class B_Ptr7 {
	Intra_Ptr7 f;
}