package test.NPTest;

import java.util.Random;

public class Intra_If2 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		Intra_If2 o = new Intra_If2();
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10) {
			o.x++; //safe
			System.out.println(o.x); //safe
			if (o.x > 10 && o == null) { //safe
				o = null;
			}
			if (r < 5) {
				System.out.println(o.x); //safe 
			}
		}
	}
	
	int x;
}
