package test.NPTest;

import java.util.Random;

public class Intra_Ptr3 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		Intra_Ptr3 o1 = null;
		Intra_Ptr3 o2 = o1; //Alias
		Intra_Ptr3 o3 = o2; //Alias
		Intra_Ptr3 o4 = o3; //Alias
		Intra_Ptr3 o5 = o4; //Alias
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10) {
			o5.x++; //bug
			o5 = new Intra_Ptr3();
			System.out.println(o5.x); //safe
		}
	}
	
	int x;
}
