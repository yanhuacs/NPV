package test.NPTest;

import java.util.Random;

public class Intra_Ptr4 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		Intra_Ptr4 o1 = new Intra_Ptr4();
		Intra_Ptr4 o2 = o1; //Alias
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10) {
			o2.x++; //safe
			System.out.println(o2.x); //safe
			if (o1.x > 10) { //safe
				o2 = null;
			}
			if (r < 5) {
				System.out.println(o2.x); //bug
			}
		}
	}
	
	int x;
}
