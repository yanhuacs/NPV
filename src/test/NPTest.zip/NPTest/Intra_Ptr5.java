package test.NPTest;

import java.util.Random;

public class Intra_Ptr5 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		A_Ptr5 a = new A_Ptr5();
		a.f = new Intra_Ptr5();
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10) {
			a.f.x++; //safe
			a.f = null;
			System.out.println(a.f.x); //bug
		}
	}
	
	int x;
}

class A_Ptr5 {
	Intra_Ptr5 f;
}