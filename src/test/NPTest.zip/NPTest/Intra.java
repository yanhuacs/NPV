package test.NPTest;

public class Intra {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		/*A[] as = new A[10];
		as[1].x = 101;
		as[1].foo();*/
		A a = new A();
		//a.x = 100;
		for (int k = 0; k < 5; ++k) {
			a.foo();
		}
		//if (a.x > 100)
		//	a = new A();
//		int y = a.bar(a.bar(5));
//		System.out.println(y);
		if (a.x < 10)
			a = null;
		
		if (a == null) {
			if (a != null)
				System.out.println("11");
			else
				System.out.println("22");
			System.out.println(a.x);
		}
	}
}

class A
{
	public void foo() {
		x++;
		System.out.println("calling a method." + x);
	}
	
	public int bar(int n) {
		return x + n;
	}
	
	int x;
}