package test.NPTest;

import java.util.Random;

public class Intra_Loop1 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		A_loop1 a = new A_loop1();
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10)
			a = null;
		for (int k = 0; k < 5 && a != null; ++k) { //This condition makes the deref safe
			if (a == null)
				System.out.println(a.x + 1); //safe
		}
	}
}

class A_loop1
{
	int x;
}