package test.NPTest;

import java.util.Random;

public class Intra_Array {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		A_array[] a = new A_array[10];
		a[4] = new A_array();
		a[3] = new A_array();
		for (int k = 0; k < 5; ++k) {
			a[3].foo(); //safe
		}
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10)
			a[3] = null; //safe
		
		if (a[3] == null) { //safe
			if (a[4] != null) //safe
				System.out.println(a[3].x); //bug
			else
				System.out.println("22");
			System.out.println(a[3].x); //bug
		}
	}
}

class A_array
{
	public void foo() {
		x++;
		System.out.println("calling a method." + x);
	}
	
	public int bar(int n) {
		return x + n;
	}
	
	int x;
}