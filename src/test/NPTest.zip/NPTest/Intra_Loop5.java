package test.NPTest;

import java.util.Random;

public class Intra_Loop5 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		A_loop5 a = new A_loop5();
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10)
			;//a = null;
		for (int i = 0; i < 5; ++i) {
			for (int k = 0; k < 5 && a == null; ++k) { 
				if (a == null)
					System.out.println(a.x + 1); //bug
				else
					System.out.println(a.x + 2); //safe
				if (a != null)
					System.out.println(a.x + 3); //safe
			}
			a = null; //This assignment makes the deref unsafe
		}
	}
}

class A_loop5
{
	int x;
}