package test.NPTest;

import java.util.Random;

public class Intra_Ptr1 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		Intra_Ptr1 o1 = new Intra_Ptr1();
		Intra_Ptr1 o2 = o1; //Alias
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10) {
			o2.x++; //safe
			o2 = null;
			System.out.println(o2.x); //bug
		}
	}
	
	int x;
}
