package test.NPTest;

import java.util.Random;

public class Intra_Ptr2 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		Intra_Ptr2 o1 = new Intra_Ptr2();
		Intra_Ptr2 o2 = o1; //Alias
		Intra_Ptr2 o3 = o2; //Alias
		Intra_Ptr2 o4 = o3; //Alias
		Intra_Ptr2 o5 = o4; //Alias
		Random rand = new Random();
		int r = rand.nextInt(100);
		if (r < 10) {
			o5.x++; //safe
			o5 = null;
			System.out.println(o5.x); //bug
		}
	}
	
	int x;
}
