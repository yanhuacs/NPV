package test.NPTest;

import java.util.Random;

public class Intra_Ptr6 {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		A_Ptr6 a = new A_Ptr6();
		A_Ptr6 b = new A_Ptr6();
		b.f = new Intra_Ptr6();
		Random rand = new Random();
		int r = rand.nextInt(100);
		A_Ptr6 c = null;
		if (r > 8)
			c = a;
		else
			c = b;
		if (r < 10) {
			a.f.x++; //safe
			c.f = null;
			System.out.println(a.f.x); //bug
		}
	}
	
	int x;
}

class A_Ptr6 {
	Intra_Ptr6 f;
}