package test.NPTest;

public class Loop {
	public static void main(String[] args) {
		doStuff();
	}
	
	public static void doStuff() {
		boolean flag = false;
		B a = new B();
		for (int k = 0; k < 5; ++k) {
			foo(a);
		}
		if (a.x < 10) {
			foo(a);
			flag = true;
		}
		System.out.println(a.x);
		System.out.println(flag);
	}
	
	public static void foo(B b) {
		b.x++;
		System.out.println("calling foo." + b.x);
	}
}

class B
{	
	int x;
}